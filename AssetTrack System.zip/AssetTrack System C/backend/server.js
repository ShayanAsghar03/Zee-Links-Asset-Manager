const path = require('node:path');
const fs = require('node:fs');
const { promisify } = require('node:util');
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const PORT = process.env.PORT || 5000;
const UPLOADS_DIR = path.join(__dirname, 'uploads');
const DATABASE_PATH = path.join(__dirname, 'assets.db');

fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const db = new sqlite3.Database(DATABASE_PATH, (error) => {
  if (error) {
    console.error('Could not open SQLite database:', error.message);
    process.exit(1);
  }
});

db.run(`
  CREATE TABLE IF NOT EXISTS assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id TEXT NOT NULL UNIQUE,
    category TEXT NOT NULL,
    image_path TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  )
`, (error) => {
  if (error) {
    console.error('Could not create assets table:', error.message);
    process.exit(1);
  }
});

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(UPLOADS_DIR));

const storage = multer.diskStorage({
  destination: (_req, _file, callback) => callback(null, UPLOADS_DIR),
  filename: (_req, file, callback) => {
    const extension = path.extname(file.originalname).toLowerCase();
    const safeExtension = /^\.[a-z0-9]{1,10}$/.test(extension) ? extension : '';
    callback(null, `${Date.now()}-${Math.round(Math.random() * 1e9)}${safeExtension}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, callback) => {
    if (!file.mimetype.startsWith('image/')) {
      return callback(new Error('Only image files are allowed.'));
    }
    callback(null, true);
  },
});

const dbAll = promisify(db.all.bind(db));
const insertAsset = (assetId, category, imagePath) => new Promise((resolve, reject) => {
  db.run(
    'INSERT INTO assets (asset_id, category, image_path) VALUES (?, ?, ?)',
    [assetId, category, imagePath],
    function onInsert(error) {
      if (error) return reject(error);
      resolve(this.lastID);
    },
  );
});

// Multipart field names: asset_id, category, and image (the image file).
app.post('/api/assets', (req, res, next) => {
  upload.single('image')(req, res, async (uploadError) => {
    if (uploadError) return next(uploadError);

    const assetId = typeof req.body.asset_id === 'string' ? req.body.asset_id.trim() : '';
    const category = typeof req.body.category === 'string' ? req.body.category.trim() : '';

    if (!assetId || !category || !req.file) {
      if (req.file) fs.unlink(req.file.path, () => {});
      return res.status(400).json({ error: 'asset_id, category, and image are required.' });
    }

    const imagePath = `/uploads/${req.file.filename}`;

    try {
      const insertedId = await insertAsset(assetId, category, imagePath);
      const rows = await dbAll('SELECT * FROM assets WHERE id = ?', [insertedId]);
      return res.status(201).json(rows[0]);
    } catch (error) {
      if (req.file) fs.unlink(req.file.path, () => {});
      if (error.code === 'SQLITE_CONSTRAINT') {
        return res.status(409).json({ error: 'An asset with this asset_id already exists.' });
      }
      return next(error);
    }
  });
});

app.get('/api/assets', async (_req, res, next) => {
  try {
    const assets = await dbAll('SELECT * FROM assets ORDER BY created_at DESC, id DESC');
    res.json(assets);
  } catch (error) {
    next(error);
  }
});

app.get('/api/assets/search', async (req, res, next) => {
  const query = typeof req.query.q === 'string' ? req.query.q.trim() : '';
  if (!query) return res.status(400).json({ error: 'Provide a search term with ?q=.' });

  try {
    const assets = await dbAll(
      'SELECT * FROM assets WHERE asset_id LIKE ? ORDER BY created_at DESC, id DESC',
      [`%${query}%`],
    );
    res.json(assets);
  } catch (error) {
    next(error);
  }
});

app.use((error, _req, res, _next) => {
  if (res.headersSent) return;
  const status = error instanceof multer.MulterError ? 400 : 500;
  if (status === 500) console.error(error);
  res.status(status).json({ error: error.message || 'Internal server error.' });
});

const server = app.listen(PORT, () => {
  console.log(`Asset management API listening at http://localhost:${PORT}`);
});

function closeGracefully() {
  server.close(() => {
    db.close((error) => {
      if (error) console.error('Error closing database:', error.message);
      process.exit(error ? 1 : 0);
    });
  });
}

process.on('SIGINT', closeGracefully);
process.on('SIGTERM', closeGracefully);
