SQLite database module goes here.
