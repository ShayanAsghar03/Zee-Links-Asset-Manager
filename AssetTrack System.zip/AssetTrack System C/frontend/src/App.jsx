import { useEffect, useMemo, useRef, useState } from 'react'
import {
  ArrowUpRight,
  Box,
  Camera,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  Eye,
  HardDrive,
  ImagePlus,
  Layers3,
  LayoutDashboard,
  LoaderCircle,
  Network,
  Plus,
  Search,
  Server,
  ShieldCheck,
  Sparkles,
  Upload,
  X,
} from 'lucide-react'

const categories = ['Camera', 'Server', 'Networking', 'Workstation', 'Other']
const API_BASE_URL = 'http://localhost:5000'

async function readApiResponse(response) {
  let data = {}
  try {
    data = await response.json()
  } catch {
    // Keep a useful fallback for empty or non-JSON error responses.
  }
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status}).`)
  return data
}

function getImageUrl(imagePath) {
  if (!imagePath) return ''
  return imagePath.startsWith('http') ? imagePath : `${API_BASE_URL}${imagePath}`
}

const categoryIcons = {
  Camera,
  Server,
  Networking: Network,
  Workstation: HardDrive,
  Other: Box,
}

function formatDate(value) {
  if (!value) return 'Just now'
  const normalized = value.includes('T') ? value : `${value.replace(' ', 'T')}Z`
  const date = new Date(normalized)
  if (Number.isNaN(date.getTime())) return value
  return new Intl.DateTimeFormat('en', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  }).format(date)
}

function App() {
  const [assets, setAssets] = useState([])
  const [assetId, setAssetId] = useState('')
  const [category, setCategory] = useState('')
  const [photo, setPhoto] = useState(null)
  const [preview, setPreview] = useState('')
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(true)
  const [reloadKey, setReloadKey] = useState(0)
  const [loadFailed, setLoadFailed] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [selectedAsset, setSelectedAsset] = useState(null)
  const fileRef = useRef(null)

  useEffect(() => {
    let active = true
    fetch(`${API_BASE_URL}/api/assets`)
      .then(readApiResponse)
      .then((data) => {
        if (!Array.isArray(data)) throw new Error('The API returned an unexpected asset list.')
        return data
      })
      .then((data) => { if (active) { setAssets(data); setLoadFailed(false) } })
      .catch((fetchError) => { if (active) { setError(fetchError.message); setLoadFailed(true) } })
      .finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [reloadKey])

  useEffect(() => {
    if (!selectedAsset) return undefined
    function handleKeyDown(event) {
      if (event.key === 'Escape') setSelectedAsset(null)
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [selectedAsset])

  useEffect(() => {
    if (!photo) {
      setPreview('')
      return undefined
    }
    const objectUrl = URL.createObjectURL(photo)
    setPreview(objectUrl)
    return () => URL.revokeObjectURL(objectUrl)
  }, [photo])

  const categoryCount = useMemo(() => new Set(assets.map((asset) => asset.category)).size, [assets])
  const filteredAssets = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase()
    return normalizedQuery
      ? assets.filter((asset) => asset.asset_id.toLowerCase().includes(normalizedQuery))
      : assets
  }, [assets, query])

  function handlePhotoChange(event) {
    const file = event.target.files?.[0]
    setPhoto(file || null)
  }

  async function handleSubmit(event) {
    event.preventDefault()
    setError('')
    setLoadFailed(false)
    setNotice('')
    if (!photo) {
      setError('Please select an asset photograph.')
      return
    }

    const payload = new FormData()
    payload.append('asset_id', assetId.trim())
    payload.append('category', category)
    payload.append('image', photo)

    setSaving(true)
    try {
      const response = await fetch(`${API_BASE_URL}/api/assets`, { method: 'POST', body: payload })
      const data = await readApiResponse(response)
      setAssets((current) => [data, ...current])
      setAssetId('')
      setCategory('')
      setPhoto(null)
      if (fileRef.current) fileRef.current.value = ''
      setNotice('Asset added to your inventory.')
    } catch (saveError) {
      setError(saveError.message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#f7f8fa] text-slate-900">
      <aside className="fixed inset-y-0 left-0 z-20 hidden w-[248px] flex-col border-r border-slate-200/80 bg-white px-5 py-6 lg:flex">
        <a href="#overview" className="mb-10 flex items-center gap-3 px-1">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-600 text-white shadow-lg shadow-indigo-600/20">
            <Layers3 size={21} strokeWidth={2.2} />
          </span>
          <span>
            <span className="block text-[15px] font-bold tracking-tight text-slate-900">Zee Links</span>
            <span className="block text-xs font-medium text-slate-500">Asset Manager</span>
          </span>
        </a>

        <p className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[0.16em] text-slate-400">Workspace</p>
        <nav className="space-y-1">
          <a href="#overview" className="flex items-center gap-3 rounded-xl bg-indigo-50 px-3 py-2.5 text-sm font-semibold text-indigo-700">
            <LayoutDashboard size={18} /> Overview
          </a>
          <a href="#inventory" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-500 transition hover:bg-slate-50 hover:text-slate-800">
            <Box size={18} /> Asset inventory
          </a>
        </nav>

        <div className="mt-auto rounded-2xl border border-indigo-100 bg-gradient-to-br from-indigo-50 to-white p-4">
          <span className="mb-3 flex h-9 w-9 items-center justify-center rounded-xl bg-white text-indigo-600 shadow-sm">
            <ShieldCheck size={18} />
          </span>
          <p className="text-sm font-semibold text-slate-800">Your inventory, in view</p>
          <p className="mt-1 text-xs leading-5 text-slate-500">Keep equipment records and photos together in one place.</p>
          <div className="mt-4 flex items-center gap-1.5 text-[11px] font-semibold text-emerald-700">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> Workspace active
          </div>
        </div>
      </aside>

      <main className="min-h-screen lg:pl-[248px]">
        <header className="sticky top-0 z-10 border-b border-slate-200/80 bg-white/90 backdrop-blur-xl">
          <div className="mx-auto flex min-h-[72px] max-w-[1440px] flex-wrap items-center justify-between gap-y-3 px-5 py-3 sm:px-8 xl:px-10">
            <div className="flex items-center gap-3 lg:hidden">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-600 text-white"><Layers3 size={19} /></span>
              <div className="leading-tight"><p className="text-sm font-bold">Zee Links</p><p className="text-[11px] text-slate-500">Asset Manager</p></div>
            </div>
            <div className="hidden text-sm text-slate-500 lg:block">Workspace <span className="mx-2 text-slate-300">/</span> <span className="font-semibold text-slate-800">Overview</span></div>
            <label className="relative order-3 w-full md:order-none md:ml-auto md:w-[260px]">
              <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input value={query} onChange={(event) => setQuery(event.target.value)} aria-label="Search assets by Asset ID" placeholder="Search by Asset ID" className="h-10 w-full rounded-lg border border-slate-200 bg-slate-50/70 pl-9 pr-3 text-xs text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-indigo-300 focus:bg-white focus:ring-3 focus:ring-indigo-100" />
            </label>
            <div className="ml-auto flex items-center gap-3">
              <span className="hidden items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-600 sm:flex">
                <span className="h-2 w-2 rounded-full bg-emerald-500" /> All systems operational
              </span>
              <button type="button" aria-label="Help" className="flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 text-slate-500 transition hover:bg-slate-50"><CircleHelp size={17} /></button>
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-amber-100 text-xs font-bold text-amber-800 ring-2 ring-white">ZL</div>
            </div>
          </div>
        </header>

        <div className="mx-auto max-w-[1440px] px-5 py-7 sm:px-8 sm:py-9 xl:px-10">
          <section id="overview" className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div>
              <div className="mb-2 flex items-center gap-2 text-xs font-semibold text-indigo-600"><Sparkles size={14} /> ASSET OPERATIONS</div>
              <h1 className="text-[27px] font-bold tracking-tight text-slate-900 sm:text-[32px]">Asset overview</h1>
              <p className="mt-1.5 text-sm text-slate-500">A clear view of the equipment your team depends on.</p>
            </div>
            <a href="#add-asset" className="inline-flex w-fit items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white shadow-md shadow-indigo-600/15 transition hover:bg-indigo-700">
              <Plus size={17} /> Add new asset
            </a>
          </section>

          {error && <div role="alert" className="mb-5 flex items-center justify-between gap-4 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700"><span>{error}</span><div className="flex shrink-0 items-center gap-3">{loadFailed && <button onClick={() => { setError(''); setLoading(true); setReloadKey((key) => key + 1) }} className="font-semibold underline underline-offset-2">Retry</button>}<button onClick={() => setError('')} aria-label="Dismiss error"><X size={16} /></button></div></div>}
          {notice && <div role="status" className="mb-5 flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700"><Check size={16} />{notice}<button className="ml-auto" onClick={() => setNotice('')} aria-label="Dismiss notice"><X size={16} /></button></div>}

          <section aria-label="Asset statistics" className="mb-7 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <StatCard icon={Box} label="Total assets" value={assets.length} caption="Tracked in your workspace" tone="indigo" />
            <StatCard icon={Layers3} label="Categories" value={categoryCount} caption="Represented in your inventory" tone="teal" />
          </section>

          <div className="grid items-start gap-6 xl:grid-cols-[minmax(0,1fr)_350px]">
            <section id="inventory" className="min-w-0 overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-sm shadow-slate-200/30">
              <div className="flex flex-col gap-4 border-b border-slate-100 px-5 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-6">
                <div>
                  <h2 className="text-base font-bold text-slate-900">Asset inventory</h2>
                  <p className="mt-1 text-xs text-slate-500">A complete list of registered equipment</p>
                </div>
                <span className="text-xs font-medium text-slate-400">{filteredAssets.length} result{filteredAssets.length === 1 ? '' : 's'}</span>
              </div>

              <div className="hidden overflow-x-auto md:block">
                <table className="w-full min-w-[650px] text-left">
                  <thead><tr className="bg-slate-50/70 text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400"><th className="px-6 py-3.5">Asset</th><th className="px-4 py-3.5">Category</th><th className="px-4 py-3.5">Date added</th><th className="px-4 py-3.5">Status</th><th className="px-6 py-3.5" /></tr></thead>
                  <tbody className="divide-y divide-slate-100">
                    {loading ? <TableMessage colSpan={5} icon={LoaderCircle} text="Loading your inventory…" spinning /> : filteredAssets.map((asset) => <AssetRow key={asset.id} asset={asset} onView={() => setSelectedAsset(asset)} />)}
                  </tbody>
                </table>
                {!loading && filteredAssets.length === 0 && <EmptyInventory searching={Boolean(query)} />}
              </div>

              <div className="divide-y divide-slate-100 md:hidden">
                {loading ? <div className="flex items-center justify-center gap-2 px-5 py-12 text-xs text-slate-400"><LoaderCircle size={16} className="animate-spin" />Loading your inventory…</div> : filteredAssets.map((asset) => <AssetCard key={asset.id} asset={asset} onView={() => setSelectedAsset(asset)} />)}
                {!loading && filteredAssets.length === 0 && <EmptyInventory searching={Boolean(query)} />}
              </div>

              <div className="flex items-center justify-between border-t border-slate-100 px-5 py-3.5 text-xs text-slate-400 sm:px-6">
                <span>Showing <strong className="font-semibold text-slate-600">{filteredAssets.length}</strong> of <strong className="font-semibold text-slate-600">{assets.length}</strong> assets</span>
                <span className="inline-flex items-center gap-1.5"><Clock3 size={13} /> Live inventory</span>
              </div>
            </section>

            <section id="add-asset" className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm shadow-slate-200/30 sm:p-6">
              <div className="mb-5 flex items-start justify-between">
                <div><div className="mb-2 flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600"><Plus size={19} /></div><h2 className="text-base font-bold text-slate-900">Register an asset</h2><p className="mt-1 text-xs text-slate-500">Add an item to your inventory</p></div>
                <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-semibold text-slate-500">NEW ITEM</span>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="asset-id" className="mb-1.5 block text-xs font-semibold text-slate-700">Asset ID <span className="text-rose-500">*</span></label>
                  <input id="asset-id" required value={assetId} onChange={(event) => setAssetId(event.target.value)} placeholder="e.g. ZL-CAM-001" className="h-10 w-full rounded-lg border border-slate-200 px-3 text-sm outline-none transition placeholder:text-slate-400 focus:border-indigo-400 focus:ring-3 focus:ring-indigo-100" />
                  <p className="mt-1.5 text-[10px] text-slate-400">Use a unique identification number</p>
                </div>
                <div>
                  <label htmlFor="asset-category" className="mb-1.5 block text-xs font-semibold text-slate-700">Asset category <span className="text-rose-500">*</span></label>
                  <div className="relative">
                    <select id="asset-category" required value={category} onChange={(event) => setCategory(event.target.value)} className="h-10 w-full appearance-none rounded-lg border border-slate-200 bg-white px-3 pr-9 text-sm text-slate-700 outline-none transition focus:border-indigo-400 focus:ring-3 focus:ring-indigo-100">
                      <option value="" disabled>Select a category</option>
                      {categories.map((option) => <option key={option} value={option}>{option}</option>)}
                    </select>
                    <ChevronDown size={15} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  </div>
                </div>
                <div>
                  <div className="mb-1.5 flex items-center justify-between"><label htmlFor="asset-photo" className="text-xs font-semibold text-slate-700">Asset photograph <span className="text-rose-500">*</span></label><span className="text-[10px] text-slate-400">JPG, PNG up to 5 MB</span></div>
                  <input ref={fileRef} id="asset-photo" type="file" accept="image/*" required onChange={handlePhotoChange} className="sr-only" />
                  {preview ? (
                    <div className="group relative h-40 overflow-hidden rounded-xl border border-slate-200 bg-slate-50">
                      <img src={preview} alt="Selected asset preview" className="h-full w-full object-cover" />
                      <div className="absolute inset-x-0 bottom-0 flex items-center justify-between bg-gradient-to-t from-black/65 to-transparent px-3 pb-3 pt-8 text-white"><span className="max-w-[75%] truncate text-xs font-medium">{photo?.name}</span><button type="button" onClick={() => { setPhoto(null); if (fileRef.current) fileRef.current.value = '' }} className="rounded-md bg-white/20 p-1.5 backdrop-blur transition hover:bg-white/35" aria-label="Remove image"><X size={14} /></button></div>
                    </div>
                  ) : (
                    <label htmlFor="asset-photo" className="flex h-36 cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed border-slate-300 bg-slate-50/70 text-center transition hover:border-indigo-300 hover:bg-indigo-50/40">
                      <span className="mb-2 flex h-9 w-9 items-center justify-center rounded-xl bg-white text-indigo-600 shadow-sm"><ImagePlus size={18} /></span>
                      <span className="text-xs font-semibold text-slate-700">Click to upload a photo</span>
                      <span className="mt-1 text-[10px] text-slate-400">or drag and drop an image</span>
                    </label>
                  )}
                </div>
                <button disabled={saving} type="submit" className="flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-indigo-600 text-sm font-semibold text-white shadow-md shadow-indigo-600/15 transition hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-65">
                  {saving ? <><LoaderCircle size={16} className="animate-spin" /> Saving asset…</> : <><Upload size={16} /> Save asset</>}
                </button>
              </form>
              <p className="mt-4 flex items-center justify-center gap-1.5 text-[10px] text-slate-400"><ShieldCheck size={13} /> Your asset details are stored securely</p>
            </section>
          </div>

          <footer className="mt-8 flex flex-col items-center justify-between gap-2 border-t border-slate-200/70 py-5 text-[11px] text-slate-400 sm:flex-row">
            <span>© {new Date().getFullYear()} Zee Links Asset Manager</span>
            <span className="inline-flex items-center gap-1.5">Built for a better-equipped team <ArrowUpRight size={12} /></span>
          </footer>
        </div>
      </main>
      {selectedAsset && <AssetDetailsModal asset={selectedAsset} onClose={() => setSelectedAsset(null)} />}
    </div>
  )
}

function StatCard({ icon: Icon, label, value, caption, tone }) {
  const iconTone = tone === 'indigo' ? 'bg-indigo-50 text-indigo-600' : 'bg-teal-50 text-teal-700'
  return (
    <article className="flex items-center justify-between rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm shadow-slate-200/30 sm:p-6">
      <div><p className="text-xs font-semibold text-slate-500">{label}</p><p className="mt-2 text-[30px] font-bold leading-none tracking-tight text-slate-900">{value}</p><p className="mt-2 text-[11px] text-slate-400">{caption}</p></div>
      <span className={`flex h-11 w-11 items-center justify-center rounded-xl ${iconTone}`}><Icon size={20} /></span>
    </article>
  )
}

function CategoryBadge({ category }) {
  const Icon = categoryIcons[category] || Box
  return <span className="inline-flex items-center gap-1.5 rounded-lg bg-slate-100 px-2.5 py-1.5 text-[11px] font-semibold text-slate-600"><Icon size={13} />{category || 'Other'}</span>
}

function AssetPhoto({ asset, size = 'h-10 w-10' }) {
  const [failed, setFailed] = useState(false)
  const src = getImageUrl(asset.image_path)
  return (
    <div className={`flex ${size} shrink-0 items-center justify-center overflow-hidden rounded-xl bg-slate-100 text-slate-400`}>
      {src && !failed ? <img src={src} alt={`${asset.asset_id} asset`} onError={() => setFailed(true)} className="h-full w-full object-cover" /> : <ImagePlus size={17} />}
    </div>
  )
}

function AssetRow({ asset, onView }) {
  return (
    <tr className="transition hover:bg-slate-50/70">
      <td className="px-6 py-3.5"><div className="flex items-center gap-3"><AssetPhoto asset={asset} /><div><p className="text-xs font-semibold text-slate-800">{asset.asset_id}</p><p className="mt-1 text-[10px] text-slate-400">Identification number</p></div></div></td>
      <td className="px-4 py-3.5"><CategoryBadge category={asset.category} /></td>
      <td className="px-4 py-3.5"><span className="inline-flex items-center gap-1.5 text-xs text-slate-500"><Clock3 size={13} className="text-slate-400" />{formatDate(asset.created_at)}</span></td>
      <td className="px-4 py-3.5"><span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-2 py-1 text-[10px] font-semibold text-emerald-700"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> Active</span></td>
      <td className="px-6 py-3.5 text-right"><button type="button" onClick={onView} className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-2.5 py-2 text-[11px] font-semibold text-slate-600 transition hover:border-indigo-200 hover:bg-indigo-50 hover:text-indigo-700"><Eye size={14} /> View details</button></td>
    </tr>
  )
}

function AssetCard({ asset, onView }) {
  return <article className="flex items-center gap-3 px-5 py-4"><AssetPhoto asset={asset} size="h-12 w-12" /><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center justify-between gap-2"><p className="truncate text-xs font-semibold text-slate-800">{asset.asset_id}</p><CategoryBadge category={asset.category} /></div><p className="mt-2 flex items-center gap-1.5 text-[10px] text-slate-400"><Clock3 size={12} />{formatDate(asset.created_at)}</p><button type="button" onClick={onView} className="mt-2 inline-flex items-center gap-1.5 text-[11px] font-semibold text-indigo-600 hover:text-indigo-800"><Eye size={13} /> View details</button></div></article>
}

function AssetDetailsModal({ asset, onClose }) {
  const image = getImageUrl(asset.image_path)
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-slate-950/45 p-4 backdrop-blur-[3px]" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose() }}>
      <section role="dialog" aria-modal="true" aria-labelledby="asset-modal-title" className="my-auto w-full max-w-[650px] overflow-hidden rounded-2xl bg-white shadow-2xl shadow-slate-950/20">
        <div className="flex items-start justify-between border-b border-slate-100 px-5 py-4 sm:px-6">
          <div><p className="text-[10px] font-bold uppercase tracking-[0.14em] text-indigo-600">Asset details</p><h2 id="asset-modal-title" className="mt-1 text-lg font-bold tracking-tight text-slate-900">{asset.asset_id}</h2></div>
          <button type="button" onClick={onClose} aria-label="Close asset details" className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"><X size={18} /></button>
        </div>
        <div className="grid gap-5 p-5 sm:grid-cols-[1.1fr_0.9fr] sm:p-6">
          <div className="flex min-h-[220px] items-center justify-center overflow-hidden rounded-xl bg-slate-100 sm:min-h-[290px]">
            {image ? <img src={image} alt={`Full size photograph of ${asset.asset_id}`} className="max-h-[420px] w-full object-contain" /> : <div className="flex flex-col items-center gap-2 text-sm text-slate-400"><ImagePlus size={28} />No photograph available</div>}
          </div>
          <div className="flex flex-col">
            <p className="mb-3 text-xs font-semibold text-slate-500">Identification details</p>
            <DetailField label="Asset ID" value={asset.asset_id} />
            <DetailField label="Category" value={asset.category} />
            <DetailField label="Record number" value={String(asset.id)} />
            <div className="mt-3 rounded-xl bg-slate-50 p-3.5">
              <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Created at</p>
              <p className="mt-1.5 text-xs font-semibold text-slate-700">{formatDate(asset.created_at)}</p>
              <p className="mt-1 break-all font-mono text-[10px] text-slate-500">{asset.created_at}</p>
            </div>
            <button type="button" onClick={onClose} className="mt-auto pt-5 text-left text-xs font-semibold text-indigo-600 hover:text-indigo-800">Close details</button>
          </div>
        </div>
      </section>
    </div>
  )
}

function DetailField({ label, value }) {
  return <div className="border-b border-slate-100 py-3"><p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">{label}</p><p className="mt-1 text-sm font-semibold text-slate-800">{value || '—'}</p></div>
}

function TableMessage({ colSpan, icon: Icon, text, spinning = false }) {
  return <tr><td colSpan={colSpan} className="px-6 py-12 text-center"><div className="inline-flex items-center gap-2 text-xs text-slate-400"><Icon size={16} className={spinning ? 'animate-spin' : ''} />{text}</div></td></tr>
}

function EmptyInventory({ searching }) {
  return <div className="px-5 py-12 text-center"><span className="mx-auto mb-3 flex h-11 w-11 items-center justify-center rounded-2xl bg-slate-100 text-slate-400"><Box size={20} /></span><p className="text-sm font-semibold text-slate-700">{searching ? 'No matching assets' : 'Your inventory is ready'}</p><p className="mx-auto mt-1 max-w-[250px] text-xs leading-5 text-slate-400">{searching ? 'Try another Asset ID or clear your search.' : 'Add your first asset to start building your equipment inventory.'}</p></div>
}

export default App
